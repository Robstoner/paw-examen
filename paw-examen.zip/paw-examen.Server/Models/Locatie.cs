﻿namespace paw_examen.Server.Models
{
    public class Locatie
    {
        public int Id {  get; set; }
        public string Judet { get; set; }
        public string Oras {  get; set; }
        public int Numar_locuitori { get; set; }
    }
}
